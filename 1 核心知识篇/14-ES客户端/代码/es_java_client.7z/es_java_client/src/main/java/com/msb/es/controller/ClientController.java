package com.msb.es.controller;

import com.msb.es.dto.ResultDto;
import com.msb.es.util.ESClient;
import lombok.SneakyThrows;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.*;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.Fuzziness;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static org.elasticsearch.index.query.QueryBuilders.matchQuery;

@RestController
@RequestMapping("/car")
public class ClientController {
    RestHighLevelClient client = ESClient.getInstance().getHighLevelClient();

    //region 分页查询
    @RequestMapping("/carInfo")
    @SneakyThrows
    public ResultDto carInfo(@RequestParam(value = "kw", required = true) String keyword,
                             @RequestParam(value = "from", required = true) Integer from,
                             @RequestParam(value = "size", required = true) Integer size) {

        SearchRequest searchRequest = new SearchRequest("msb_car_info");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder
                .query(QueryBuilders.matchQuery("name", keyword))
                .from(from)
                .size(size);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
//        ESClient.getInstance().closeClient();
        ResultDto res = new ResultDto();
        res.setData(searchResponse.getHits().getHits());
        return res;
    }
    //endregion

    //region fuzzy
    @RequestMapping("/fuzzy")
    @SneakyThrows
    public SearchHit[] fuzzy(String name) {
        SearchRequest searchRequest = new SearchRequest("msb_car_info");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder()
                .query(QueryBuilders.fuzzyQuery("name", name)
                .fuzziness(Fuzziness.AUTO))
                .size(100);
        searchRequest.source(searchSourceBuilder);
        SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
        return response.getHits().getHits();
    }
    //endregion

    //region Bulk
    @RequestMapping("/bulk")
    @SneakyThrows
    public ResultDto bulk() {
        BulkRequest request = new BulkRequest("msb_car_info");
        request.add(new DeleteRequest("msb_car_info", "13"));
        request.add(new UpdateRequest("msb_car_info", "22")
                .doc(XContentType.JSON, "name", "宝马666"));
        request.add(new IndexRequest("msb_car_info").id("4")
                .source(XContentType.JSON, "name", "奥迪双钻"));
        BulkResponse bulkResponse = client.bulk(request, RequestOptions.DEFAULT);
        return null;
    }
    //endregion

    //region Multi-Search
    @RequestMapping("/multiSearch")
    @SneakyThrows
    public ResultDto multiSearch() {
        MultiSearchRequest request = new MultiSearchRequest();

        SearchRequest firstSearchRequest = new SearchRequest("msb_car_info");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchQuery("name", "朗动"));
        firstSearchRequest.source(searchSourceBuilder);
        request.add(firstSearchRequest);

        SearchRequest secondSearchRequest = new SearchRequest("msb_car_info");
        searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchQuery("name", "揽胜运动"));
        secondSearchRequest.source(searchSourceBuilder);
        request.add(secondSearchRequest);

        MultiSearchResponse response = client.msearch(request, RequestOptions.DEFAULT);
        return null;
    }
    //endregion

    //region Bool Request
    @RequestMapping("/boolSearch")
    @SneakyThrows
    public ResultDto boolSearch() {
        MultiSearchRequest request = new MultiSearchRequest();

        SearchRequest searchRequest = new SearchRequest("msb_car_info");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query
                (
                        QueryBuilders.boolQuery()
                                .must(matchQuery("name", "AMG"))
                                .mustNot(matchQuery("name", "A级"))
                );
        searchRequest.source(searchSourceBuilder);
        request.add(searchRequest);
        MultiSearchResponse response = client.msearch(request, RequestOptions.DEFAULT);
        return null;
    }
    //endregion
}
