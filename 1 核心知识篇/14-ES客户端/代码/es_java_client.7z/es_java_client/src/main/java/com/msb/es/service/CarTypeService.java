package com.msb.es.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.msb.es.entity.CarType;
import com.msb.es.mapper.CarTypeMapper;
import org.springframework.stereotype.Service;

@Service
public class CarTypeService extends ServiceImpl<CarTypeMapper, CarType> {
}
