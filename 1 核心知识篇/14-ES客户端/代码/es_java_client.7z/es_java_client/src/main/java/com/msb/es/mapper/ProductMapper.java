package com.msb.es.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.msb.es.entity.Product;

public interface ProductMapper extends BaseMapper<Product> {
}
