package com.msb.es.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.msb.es.entity.CarType;

public interface CarTypeMapper extends BaseMapper<CarType> {
}
