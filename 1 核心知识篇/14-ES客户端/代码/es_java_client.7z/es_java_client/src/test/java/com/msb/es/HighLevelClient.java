package com.msb.es;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;

import java.io.IOException;

public class HighLevelClient {
    private static RestClientBuilder restClientBuilder = ClientBuilders.getRestClientBuilder();
    // 实例化高级客户端
    private static RestHighLevelClient restHighLevelClient;

    public RestHighLevelClient getRestHighLevelClient() {
        restHighLevelClient = new RestHighLevelClient(
                restClientBuilder
        );
        return restHighLevelClient;
    }

    public void closeRestHighLevelClient() throws IOException {
        if (null!=restHighLevelClient){
            restHighLevelClient.close();;
        }
    }

}
